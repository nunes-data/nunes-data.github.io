# Exercise 1
# Creating two matrices
A <- matrix(c(4,7,2,5,3,8), nrow = 2, ncol = 3)
B <- matrix(c(3,-2,4,6,9,-5), nrow = 2, ncol = 3, byrow = TRUE)
A
B

sum_result = A + B
sum_result

A_transpose = t(A)
A_transpose

C <- A_transpose %*% A
D <- A %*% A_transpose
C
D

# Exercise 2
A <- matrix(c(1,3,2,-1), nrow = 2, ncol = 2, byrow = TRUE)
B <- matrix(c(2,0,1,5), nrow = 2, ncol = 2, byrow = TRUE)

det_AB <- det(A%*%B)
det_AB

det_A <- det(A)
det_A
det_B <- det(B)
det_B















